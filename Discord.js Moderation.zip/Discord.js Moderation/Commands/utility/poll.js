//This Command Is Available On Github Of Mr.TECH (Link On Youtube)
//Join Us On Discord (Link On Youtube)
//Please Subscribe Us On Youtube (Mr.TECH)

const { MessageEmbed } = require('discord.js');

module.exports = {
   name: 'poll',
   aliases: ['polling'],
   description: "create polls",
   run: async(client, message, args) => {
      
      if(!message.member.hasPermission('MANAGE_GUILD'))return message.channel.send("❌ You dont have permission to use this command")
      
      if(!args[0])
      return message.channel.send('Please enter the Query');
      
      const embed = new MessageEmbed()
      .setColor("GREEN")
      .setTitle(`Poll For ${message.guild.name} Server`)
      .setDescription(args.join(' '))
      .setFooter(message.member.displayName, message.author.displayAvatarURL(' '))
      const msg = await message.channel.send(embed)
      
      await msg.react('🅰️')
      await msg.react('🅱️')
      
      message.delete({timeout: 1000});
   }
}