//This Command Is Available On Github Of Mr.TECH (Link On Youtube)
//Join Us On Discord (Link On Youtube)
//Please Subscribe Us On Youtube (Mr.TECH)

module.exports = {
   name: "message",
   aliases: ['msg'],
   description: 'Sends message to channel',
   usage: "<channel> <message>",
   accessableby: "Administrator",
   run: async(client, message) => {
      let channel = message.mentions.channels.first()
      if(!channel) {
         return message.channel.send(`mention channel please`);
      }
      const args = message.content.split(' ').slice(2).join(' ');
      if(!args) {
         return message.channel.send(`you must enter the message you want to send`)
      }
      message.channel.send(`Sent the message to ${channel} **Successfully**`)
      channel.send(args)
   }
}