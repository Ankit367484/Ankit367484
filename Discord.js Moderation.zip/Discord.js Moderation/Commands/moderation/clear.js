//This Command Is Available On Github Of Mr.TECH (Link On Youtube)
//Join Us On Discord (Link On Youtube)
//Please Subscribe Us On Youtube (Mr.TECH)

module.exports = {
  name: 'clear',
  aliases: ['purge', 'delete'],
  description: "deletes the messages",
  run: async(client, message, args) => {
    const amount = args.join(" ");
    
    if(!amount)return message.reply('Please provide an number for me to delete')
    
    if(amount > 100)return message.reply('you cannot delete message above 100, take an number below 100')
    
    if(amount < 1)return message.reply('you need to enter at least 1 number')
    
    await message.channel.messages.fetch({limit: amount}).then(messages => {
      message.channel.bulkDelete(messages
    )});
    
    message.channel.send('**successfully deleted message**')
  }
}